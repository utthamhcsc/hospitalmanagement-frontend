import React from 'react'

export default function AmbulanceReport() {
    return (
        <div>
            
        </div>
    )
}
