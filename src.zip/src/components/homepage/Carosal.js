import React from 'react';
export default ()=>
<React.Fragment>
<div id="Home" class="carousel slide " data-ride="carousel">
  <div class="carousel-inner">
    <div class="carousel-item active">
        <img src="https://demo.smart-hospital.in/uploads/gallery/media/slider1.jpg" class="d-block w-100 vh-75" alt="..."/>
    </div>
    <div class="carousel-item">
      <img src="https://demo.smart-hospital.in/uploads/gallery/media/slider2.jpg" class="d-block w-100 vh-75" alt="..."/>
    </div>
    <div class="carousel-item">
      <img src="https://demo.smart-hospital.in/uploads/gallery/media/slider5.jpg" class="d-block w-100 vh-75" alt="..."/>
    </div>
  </div>
</div>
</React.Fragment>