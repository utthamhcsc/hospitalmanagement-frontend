import React from 'react';
export default ()=>
<div className='bg-dark'>
<div className='container'>
<div className='d-md-flex justify-content-between text-white' >
<div className='h5 py-2'>2019@Hospital Name</div>
<div className='h5 py-2'>Developed By:Pramod Sheelvant</div>
</div>
</div>
</div>